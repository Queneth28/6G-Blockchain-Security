// API Base URL
const API_BASE = 'http://127.0.0.1:8000/api';

let predictionHistory = [];
let featureOptions = {};

// Load feature options on page load
async function loadFeatureOptions() {
    try {
        const response = await fetch(`${API_BASE}/feature-options`);
        featureOptions = await response.json();
        console.log('Feature options loaded:', featureOptions);
    } catch (error) {
        console.error('Error loading feature options:', error);
    }
}

// Load model stats from backend
async function loadModelStatsFromAPI() {
    try {
        const response = await fetch(`${API_BASE}/model-stats`);
        const stats = await response.json();
        displayModelStats(stats);
    } catch (error) {
        console.error('Error loading model stats:', error);
        showToast('Failed to load model statistics');
    }
}

function displayModelStats(stats) {
    const container = document.getElementById('statsContainer');
    let html = '';

    Object.keys(stats).forEach(model => {
        const modelStats = stats[model];
        const testAcc = modelStats.test_accuracy;
        const accuracyBadge = testAcc > 52 ? 'badge-success' : testAcc > 48 ? 'badge-warning' : 'badge-danger';
        
        html += `
            <div class="stat-card">
                <h3><i class="fas fa-brain"></i> ${model}</h3>
                <div class="stat-row">
                    <span class="stat-label">Test Accuracy</span>
                    <span class="stat-value"><span class="badge ${accuracyBadge}">${testAcc.toFixed(2)}%</span></span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Train Accuracy</span>
                    <span class="stat-value">${modelStats.train_accuracy.toFixed(2)}%</span>
                </div>
                <div class="stat-row">
                    <span class="stat-label">Overfitting Gap</span>
                    <span class="stat-value">${modelStats.overfitting_gap.toFixed(2)}%</span>
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    
    document.getElementById(tabName).classList.add('active');
    event.target.closest('.tab-btn').classList.add('active');

    if (tabName === 'stats') {
        loadModelStatsFromAPI();
    } else if (tabName === 'history') {
        loadHistoryFromAPI();
    }
}

async function makePrediction(event) {
    event.preventDefault();
    showLoading();

    const formData = {
        transaction_latency: parseFloat(document.getElementById('transaction_latency').value),
        validation_time: parseFloat(document.getElementById('validation_time').value),
        encryption_time: parseFloat(document.getElementById('encryption_time').value),
        nf_type: document.getElementById('nf_type').value,
        encryption_method: document.getElementById('encryption_method').value,
        auth_method: document.getElementById('auth_method').value
    };

    try {
        const response = await fetch(`${API_BASE}/predict`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });

        if (!response.ok) {
            throw new Error('Prediction failed');
        }

        const result = await response.json();
        displayResults(result);
        hideLoading();
        showToast('Prediction completed successfully!');
    } catch (error) {
        console.error('Error:', error);
        hideLoading();
        showToast('Prediction failed. Please try again.');
    }
}

function displayResults(result) {
    const container = document.getElementById('resultsContainer');
    const section = document.getElementById('resultsSection');
    
    const models = {
        'Neural Network': result.neural_network,
        'Random Forest': result.random_forest,
        'XGBoost': result.xgboost,
        'LightGBM': result.lightgbm,
        'SVM': result.svm
    };

    // Find best model based on confidence
    let bestModel = 'Neural Network';
    let bestConfidence = 0;
    let bestPrediction = '';

    Object.keys(models).forEach(modelName => {
        const probs = models[modelName];
        const maxProb = Math.max(...Object.values(probs));
        if (maxProb > bestConfidence) {
            bestConfidence = maxProb;
            bestModel = modelName;
            bestPrediction = Object.keys(probs).find(key => probs[key] === maxProb);
        }
    });

    let html = '';
    Object.keys(models).forEach(modelName => {
        const probs = models[modelName];
        const prediction = Object.keys(probs).reduce((a, b) => probs[a] > probs[b] ? a : b);
        const confidence = probs[prediction];
        const isBest = modelName === bestModel;
        
        html += `
            <div class="result-card ${isBest ? 'best' : ''}">
                <h3>
                    ${isBest ? '<i class="fas fa-crown" style="color: #f59e0b;"></i>' : '<i class="fas fa-brain"></i>'}
                    ${modelName}
                </h3>
                <div class="prediction ${prediction.toLowerCase()}">${prediction}</div>
                <div style="color: var(--gray); font-size: 14px; margin-top: 5px;">
                    Confidence: ${confidence.toFixed(2)}%
                </div>
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: ${confidence}%"></div>
                </div>
                ${isBest ? '<div style="margin-top: 10px;"><span class="badge badge-success">Best Model</span></div>' : ''}
            </div>
        `;
    });

    container.innerHTML = html;
    section.style.display = 'block';

    // Add to local history
    predictionHistory.unshift({
        timestamp: new Date().toLocaleString(),
        transaction_latency: result.input_data['Transaction_Latency (s)'],
        validation_time: result.input_data['Validation_Time (s)'],
        encryption_time: result.input_data['Encryption_Time (s)'],
        nf_type: result.input_data['NF_Type'],
        encryption_method: result.input_data['Encryption_Method'],
        auth_method: result.input_data['Auth_Method'],
        prediction: result.ensemble_prediction,
        confidence: result.ensemble_confidence
    });

    if (predictionHistory.length > 50) {
        predictionHistory = predictionHistory.slice(0, 50);
    }
}

async function loadHistoryFromAPI() {
    try {
        const response = await fetch(`${API_BASE}/predictions?limit=50`);
        const predictions = await response.json();
        
        predictionHistory = predictions.map(p => ({
            timestamp: new Date(p.timestamp).toLocaleString(),
            transaction_latency: p.input_data['Transaction_Latency (s)'],
            validation_time: p.input_data['Validation_Time (s)'],
            encryption_time: p.input_data['Encryption_Time (s)'],
            nf_type: p.input_data['NF_Type'],
            encryption_method: p.input_data['Encryption_Method'],
            auth_method: p.input_data['Auth_Method'],
            prediction: p.ensemble_prediction,
            confidence: p.ensemble_confidence
        }));
        
        loadHistory();
    } catch (error) {
        console.error('Error loading history:', error);
        loadHistory(); // Load local history if API fails
    }
}

function loadHistory() {
    const tbody = document.getElementById('historyBody');
    
    if (predictionHistory.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="no-data">No predictions yet. Make your first prediction!</td></tr>';
        return;
    }

    let html = '';
    predictionHistory.forEach(item => {
        const statusClass = item.prediction === 'Verified' ? 'badge-success' : 'badge-danger';
        html += `
            <tr>
                <td>${item.timestamp}</td>
                <td>${item.transaction_latency}s</td>
                <td>${item.validation_time}s</td>
                <td>${item.encryption_time}s</td>
                <td>${item.nf_type}</td>
                <td>${item.encryption_method}</td>
                <td>${item.auth_method}</td>
                <td><span class="badge ${statusClass}">${item.prediction}</span></td>
                <td>${item.confidence.toFixed(2)}%</td>
            </tr>
        `;
    });
    tbody.innerHTML = html;
}

function exportHistory(format) {
    if (predictionHistory.length === 0) {
        showToast('No history to export!');
        return;
    }

    if (format === 'csv') {
        const csv = convertToCSV(predictionHistory);
        downloadFile(csv, 'prediction_history.csv', 'text/csv');
    } else if (format === 'json') {
        const json = JSON.stringify(predictionHistory, null, 2);
        downloadFile(json, 'prediction_history.json', 'application/json');
    }
    
    showToast(`History exported as ${format.toUpperCase()}!`);
}

function convertToCSV(data) {
    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(row => Object.values(row).map(val => `"${val}"`).join(','));
    return headers + '\n' + rows.join('\n');
}

function downloadFile(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}

function clearHistory() {
    if (confirm('Are you sure you want to clear all prediction history?')) {
        predictionHistory = [];
        loadHistory();
        showToast('History cleared successfully!');
    }
}

function showLoading() {
    document.getElementById('loadingOverlay').style.display = 'flex';
}

function hideLoading() {
    document.getElementById('loadingOverlay').style.display = 'none';
}

function showToast(message) {
    const toast = document.getElementById('toast');
    toast.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
    toast.style.display = 'flex';
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

// Initialize on page load
window.addEventListener('load', () => {
    loadFeatureOptions();
    loadModelStatsFromAPI();
});
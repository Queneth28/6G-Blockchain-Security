from fastapi import FastAPI, HTTPException, Body, status
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List
import pandas as pd
import numpy as np
import uvicorn
import warnings
import databases
import sqlalchemy
from sqlalchemy import Table, Column, Integer, String, Float, JSON, MetaData, DateTime
from datetime import datetime

# ML imports
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier

warnings.filterwarnings("ignore")
np.random.seed(42)

# ---------- Config ----------
CSV_FILE = "6G_Blockchain_Secure_Identity_Verification.csv"
DATABASE_URL = "sqlite:///./predictions.db"

FEATURE_COLUMNS = [
    "Transaction_Latency (s)",
    "Validation_Time (s)",
    "Encryption_Time (s)",
    "NF_Type",
    "Encryption_Method",
    "Auth_Method"
]
TARGET_COLUMN = "Authentication_Status"
categorical_features = ["NF_Type", "Encryption_Method", "Auth_Method"]
numerical_features = ["Transaction_Latency (s)", "Validation_Time (s)", "Encryption_Time (s)"]

# ---------- DB setup ----------
database = databases.Database(DATABASE_URL)
metadata = MetaData()

predictions_table = Table(
    "predictions",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("input_data", JSON, nullable=False),
    Column("neural_network", JSON, nullable=False),
    Column("xgboost", JSON, nullable=False),
    Column("lightgbm", JSON, nullable=False),
    Column("random_forest", JSON, nullable=False),
    Column("svm", JSON, nullable=False),
    Column("ensemble_prediction", String, nullable=False),
    Column("ensemble_confidence", Float, nullable=False),
    Column("timestamp", DateTime, default=datetime.utcnow),
)

engine = sqlalchemy.create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
metadata.create_all(engine)

# ---------- Load dataset ----------
try:
    df = pd.read_csv(CSV_FILE)
    print(f"✓ Loaded dataset: {len(df)} rows")
except Exception as e:
    print(f"✗ Error loading dataset: {e}")
    raise

# Keep only rows with required columns
df = df.dropna(subset=FEATURE_COLUMNS + [TARGET_COLUMN]).reset_index(drop=True)
print(f"Dataset after dropping NA: {len(df)} rows")
print("Target distribution:\n", df[TARGET_COLUMN].value_counts().to_dict())

# Features/target
X = df[FEATURE_COLUMNS].copy()
y = df[TARGET_COLUMN].copy()

# ---------- Preprocessing (fit on full dataset) ----------
label_encoders: Dict[str, LabelEncoder] = {}
for col in categorical_features:
    le = LabelEncoder()
    X[col] = le.fit_transform(X[col].astype(str))
    label_encoders[col] = le

scaler = StandardScaler()
X[numerical_features] = scaler.fit_transform(X[numerical_features])

target_encoder = LabelEncoder()
y_encoded = target_encoder.fit_transform(y)
target_classes = target_encoder.classes_.tolist()
print("Target classes:", target_classes)

# ---------- Train/test split ----------
X_train, X_test, y_train, y_test = train_test_split(
    X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
)
print(f"Train size: {len(X_train)}, Test size: {len(X_test)}")

# ---------- Train models (high accuracy, low overfitting) ----------
models: Dict[str, object] = {}

print("Training models... (may take some time)")

# Neural Network (MLP)
nn_model = MLPClassifier(
    hidden_layer_sizes=(300, 150, 75),
    max_iter=2000,
    random_state=42,
    early_stopping=True,
    validation_fraction=0.2,
    learning_rate_init=0.0005,
    alpha=0.05,
    batch_size=64,
    activation='relu',
    solver='adam'
)
nn_model.fit(X_train, y_train)
models["Neural Network"] = nn_model

# Random Forest
rf_model = RandomForestClassifier(
    n_estimators=500,
    max_depth=25,
    min_samples_split=10,
    min_samples_leaf=5,
    max_features='sqrt',
    bootstrap=True,
    random_state=42,
    n_jobs=-1
)
rf_model.fit(X_train, y_train)
models["Random Forest"] = rf_model

# XGBoost
xgb_model = XGBClassifier(
    n_estimators=1000,
    max_depth=10,
    learning_rate=0.03,
    subsample=0.8,
    colsample_bytree=0.8,
    min_child_weight=5,
    gamma=0.2,
    reg_alpha=0.1,
    reg_lambda=1.0,
    random_state=42,
    use_label_encoder=False,
    eval_metric='logloss',
    verbosity=0
)
xgb_model.fit(
    X_train, y_train,
    eval_set=[(X_test, y_test)],
    verbose=False
)
models["XGBoost"] = xgb_model

# LightGBM
lgbm_model = LGBMClassifier(
    n_estimators=1000,
    max_depth=15,
    learning_rate=0.03,
    num_leaves=64,
    min_child_samples=30,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_alpha=0.1,
    reg_lambda=1.0,
    random_state=42,
    verbosity=-1
)
lgbm_model.fit(
    X_train, y_train,
    eval_set=[(X_test, y_test)]
)
models["LightGBM"] = lgbm_model

# SVM
svm_model = SVC(
    kernel='rbf',
    C=50.0,
    gamma='scale',
    probability=True,
    class_weight='balanced',
    random_state=42
)
svm_model.fit(X_train, y_train)
models["SVM"] = svm_model

# ---------- Model stats ----------
def eval_model(m, Xtr, Xte, ytr, yte):
    tr = accuracy_score(ytr, m.predict(Xtr))
    te = accuracy_score(yte, m.predict(Xte))
    return float(tr * 100), float(te * 100), float((tr - te) * 100)

model_stats = {}
for name, m in models.items():
    tr_acc, te_acc, gap = eval_model(m, X_train, X_test, y_train, y_test)
    model_stats[name] = {"train_accuracy": tr_acc, "test_accuracy": te_acc, "overfitting_gap": gap}

print("Model stats:")
for k, v in model_stats.items():
    print(f" - {k}: test_acc={v['test_accuracy']:.2f}%, train_acc={v['train_accuracy']:.2f}%")

# ---------- FastAPI app ----------
app = FastAPI(title="6G Authentication Prediction API", version="2.1")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory="static"), name="static")


# ---------- Pydantic models ----------
class PredictionInput(BaseModel):
    transaction_latency: float
    validation_time: float
    encryption_time: float
    nf_type: str
    encryption_method: str
    auth_method: str


class PredictionOutput(BaseModel):
    id: int
    input_data: Dict
    neural_network: Dict[str, float]
    random_forest: Dict[str, float]
    xgboost: Dict[str, float]
    lightgbm: Dict[str, float]
    svm: Dict[str, float]
    ensemble_prediction: str
    ensemble_confidence: float
    timestamp: str


# ---------- Helpers ----------
def _prepare_input_from_dict(input_dict: Dict) -> pd.DataFrame:
    df_in = pd.DataFrame([input_dict])
    for col in categorical_features:
        if col in label_encoders:
            try:
                df_in[col] = label_encoders[col].transform(df_in[col].astype(str))
            except ValueError:
                df_in[col] = 0
    df_in[numerical_features] = scaler.transform(df_in[numerical_features])
    return df_in


def _run_models_and_build_result(input_dict: Dict) -> Dict:
    df_in = _prepare_input_from_dict(input_dict)
    probabilities = {}
    for model_name, model in models.items():
        proba = model.predict_proba(df_in)[0]
        proba_dict = {target_classes[i]: float(proba[i] * 100) for i in range(len(target_classes))}
        key = model_name.lower().replace(" ", "_")
        probabilities[key] = proba_dict

    all_probas = np.array([
        [v / 100 for v in probabilities["neural_network"].values()],
        [v / 100 for v in probabilities["random_forest"].values()],
        [v / 100 for v in probabilities["xgboost"].values()],
        [v / 100 for v in probabilities["lightgbm"].values()],
        [v / 100 for v in probabilities["svm"].values()]
    ])
    avg_proba = np.mean(all_probas, axis=0)
    ensemble_idx = int(np.argmax(avg_proba))
    ensemble_pred = target_classes[ensemble_idx]
    ensemble_confidence = float(avg_proba[ensemble_idx] * 100)

    return {
        "input_data": input_dict,
        "neural_network": probabilities["neural_network"],
        "random_forest": probabilities["random_forest"],
        "xgboost": probabilities["xgboost"],
        "lightgbm": probabilities["lightgbm"],
        "svm": probabilities["svm"],
        "ensemble_prediction": ensemble_pred,
        "ensemble_confidence": ensemble_confidence
    }


# ---------- Startup / Shutdown ----------
@app.on_event("startup")
async def startup():
    await database.connect()
    print("✓ Database connected")


@app.on_event("shutdown")
async def shutdown():
    await database.disconnect()
    print("✓ Database disconnected")


# ---------- Routes ----------
@app.get("/")
async def root():
    return FileResponse("static/index.html")


@app.get("/api/feature-options")
async def get_feature_options():
    try:
        options = {}
        for col in numerical_features:
            options[col] = {
                "type": "numerical",
                "min": float(df[col].min()),
                "max": float(df[col].max()),
                "mean": float(df[col].mean()),
                "std": float(df[col].std())
            }
        options["NF_Type"] = {"type": "categorical", "values": sorted(df["NF_Type"].unique().tolist())}
        options["Encryption_Method"] = {"type": "categorical", "values": sorted(df["Encryption_Method"].unique().tolist())}
        options["Auth_Method"] = {"type": "categorical", "values": sorted(df["Auth_Method"].unique().tolist())}
        return options
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/model-stats")
async def get_model_stats():
    return model_stats


@app.post("/api/predict")
async def predict_endpoint(payload: PredictionInput):
    try:
        input_dict = {
            "Transaction_Latency (s)": payload.transaction_latency,
            "Validation_Time (s)": payload.validation_time,
            "Encryption_Time (s)": payload.encryption_time,
            "NF_Type": payload.nf_type,
            "Encryption_Method": payload.encryption_method,
            "Auth_Method": payload.auth_method
        }
        res = _run_models_and_build_result(input_dict)
        res["timestamp"] = datetime.utcnow().isoformat()
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/predictions", response_model=PredictionOutput, status_code=status.HTTP_201_CREATED)
async def create_prediction(payload: PredictionInput = Body(...)):
    try:
        input_dict = {
            "Transaction_Latency (s)": payload.transaction_latency,
            "Validation_Time (s)": payload.validation_time,
            "Encryption_Time (s)": payload.encryption_time,
            "NF_Type": payload.nf_type,
            "Encryption_Method": payload.encryption_method,
            "Auth_Method": payload.auth_method
        }
        result = _run_models_and_build_result(input_dict)

        query = predictions_table.insert().values(
            input_data=result["input_data"],
            neural_network=result["neural_network"],
            xgboost=result["xgboost"],
            lightgbm=result["lightgbm"],
            random_forest=result["random_forest"],
            svm=result["svm"],
            ensemble_prediction=result["ensemble_prediction"],
            ensemble_confidence=result["ensemble_confidence"],
            timestamp=datetime.utcnow()
        )
        last_id = await database.execute(query)

        resp = {
            "id": last_id,
            "input_data": result["input_data"],
            "neural_network": result["neural_network"],
            "random_forest": result["random_forest"],
            "xgboost": result["xgboost"],
            "lightgbm": result["lightgbm"],
            "svm": result["svm"],
            "ensemble_prediction": result["ensemble_prediction"],
            "ensemble_confidence": result["ensemble_confidence"],
            "timestamp": datetime.utcnow().isoformat()
        }
        return resp
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/predictions", response_model=List[PredictionOutput])
async def list_predictions(skip: int = 0, limit: int = 50):
    try:
        query = predictions_table.select().offset(skip).limit(limit).order_by(predictions_table.c.id.desc())
        rows = await database.fetch_all(query)
        results = []
        for row in rows:
            results.append({
                "id": row["id"],
                "input_data": row["input_data"],
                "neural_network": row["neural_network"],
                "random_forest": row["random_forest"],
                "xgboost": row["xgboost"],
                "lightgbm": row["lightgbm"],
                "svm": row["svm"],
                "ensemble_prediction": row["ensemble_prediction"],
                "ensemble_confidence": row["ensemble_confidence"],
                "timestamp": row["timestamp"].isoformat() if row["timestamp"] else ""
            })
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/predictions/{prediction_id}", response_model=PredictionOutput)
async def get_prediction(prediction_id: int):
    query = predictions_table.select().where(predictions_table.c.id == prediction_id)
    row = await database.fetch_one(query)
    if not row:
        raise HTTPException(status_code=404, detail="Prediction not found")
    return {
        "id": row["id"],
        "input_data": row["input_data"],
        "neural_network": row["neural_network"],
        "random_forest": row["random_forest"],
        "xgboost": row["xgboost"],
        "lightgbm": row["lightgbm"],
        "svm": row["svm"],
        "ensemble_prediction": row["ensemble_prediction"],
        "ensemble_confidence": row["ensemble_confidence"],
        "timestamp": row["timestamp"].isoformat() if row["timestamp"] else ""
    }


@app.put("/api/predictions/{prediction_id}", response_model=PredictionOutput)
async def update_prediction(prediction_id: int, payload: PredictionInput = Body(...)):
    sel = predictions_table.select().where(predictions_table.c.id == prediction_id)
    row = await database.fetch_one(sel)
    if not row:
        raise HTTPException(status_code=404, detail="Prediction not found")
    try:
        input_dict = {
            "Transaction_Latency (s)": payload.transaction_latency,
            "Validation_Time (s)": payload.validation_time,
            "Encryption_Time (s)": payload.encryption_time,
            "NF_Type": payload.nf_type,
            "Encryption_Method": payload.encryption_method,
            "Auth_Method": payload.auth_method
        }
        result = _run_models_and_build_result(input_dict)

        update_q = (
            predictions_table.update()
            .where(predictions_table.c.id == prediction_id)
            .values(
                input_data=result["input_data"],
                neural_network=result["neural_network"],
                xgboost=result["xgboost"],
                lightgbm=result["lightgbm"],
                random_forest=result["random_forest"],
                svm=result["svm"],
                ensemble_prediction=result["ensemble_prediction"],
                ensemble_confidence=result["ensemble_confidence"],
                timestamp=datetime.utcnow()
            )
        )
        await database.execute(update_q)

        return {
            "id": prediction_id,
            "input_data": result["input_data"],
            "neural_network": result["neural_network"],
            "random_forest": result["random_forest"],
            "xgboost": result["xgboost"],
            "lightgbm": result["lightgbm"],
            "svm": result["svm"],
            "ensemble_prediction": result["ensemble_prediction"],
            "ensemble_confidence": result["ensemble_confidence"],
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/predictions/{prediction_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_prediction(prediction_id: int):
    sel = predictions_table.select().where(predictions_table.c.id == prediction_id)
    row = await database.fetch_one(sel)
    if not row:
        raise HTTPException(status_code=404, detail="Prediction not found")
    delete_q = predictions_table.delete().where(predictions_table.c.id == prediction_id)
    await database.execute(delete_q)
    return


@app.get("/api/routes")
def list_routes():
    return {
        "routes": [
            {"method": "GET", "path": "/"},
            {"method": "GET", "path": "/api/feature-options"},
            {"method": "GET", "path": "/api/model-stats"},
            {"method": "POST", "path": "/api/predict"},
            {"method": "POST", "path": "/api/predictions"},
            {"method": "GET", "path": "/api/predictions"},
            {"method": "GET", "path": "/api/predictions/{id}"},
            {"method": "PUT", "path": "/api/predictions/{id}"},
            {"method": "DELETE", "path": "/api/predictions/{id}"},
            {"method": "GET", "path": "/docs"},
            {"method": "GET", "path": "/openapi.json"}
        ]
    }


# ---------- Run ----------
if __name__ == "__main__":
    import os
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "127.0.0.1")
    print(f"Starting server at http://{host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info")